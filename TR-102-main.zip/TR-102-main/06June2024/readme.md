## 6 June - Topics Covered Today

1. *Introduction to HTML and its Tags*
2. *Creating Headings and Paragraphs*
3. *Linking Pages Using Anchor Tags*
4. *Images, Audios, and Videos Integration in HTML Page*
5. *Creating Tables and Forms*
