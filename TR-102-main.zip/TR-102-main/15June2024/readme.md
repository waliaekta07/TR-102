# Training Diary - TR-102 Web Development

## Date: 15th June 2024

### Topics Covered Today

#### Looping Statements
- **While Loop**: A control flow statement that allows code to be executed repeatedly based on a given Boolean condition.
- **Do While Loop**: Similar to the while loop, but the code block is executed at least once before the condition is tested.

---

